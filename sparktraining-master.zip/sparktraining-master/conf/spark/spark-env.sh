#!/usr/bin/env bash

HADOOP_CONF_DIR=/home/hadoop/hadoop-2.7.3/etc/hadoop
